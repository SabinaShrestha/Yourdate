class Friend < ActiveRecord::Base
  belongs_to :user
end
