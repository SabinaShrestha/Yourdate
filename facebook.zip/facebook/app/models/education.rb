class Education < ActiveRecord::Base
  belongs_to :about
end
