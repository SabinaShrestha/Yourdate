class Workplace < ActiveRecord::Base
  belongs_to :about
end
