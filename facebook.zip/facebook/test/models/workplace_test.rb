require 'test_helper'

class WorkplaceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
